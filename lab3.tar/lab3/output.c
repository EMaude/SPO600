#include <stdio.h>

void output(){
	printf("Hello World!\n");
}

int main(){
	output();
}
